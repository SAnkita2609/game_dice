# dice-game-pwa
Installable PWA for a simple Dice based game
